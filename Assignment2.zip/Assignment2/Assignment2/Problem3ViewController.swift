//
//  Problem3ViewController.swift
//  Assignment2
//
//  Created by AdoT on 6/30/16.
//  Copyright © 2016 AdoT. All rights reserved.
//

import UIKit

class Problem3ViewController: UIViewController {

    
    let width=250;
    let height=250;
    var array:[Int]=[];
    
    @IBOutlet var contentview: UIView!
    override func viewDidLoad() {
        super.viewDidLoad()
     self.view.backgroundColor=UIColor.whiteColor();
        
    }
    
    @IBAction func ClickMe(sender: AnyObject) {
        array=Engine.algorithm();
        AddUI();
    }
    
    func AddUI() {
        
        let w=width/10;
        let h=height/10;
        
        for x in 0..<10 {
            for y in 0..<10 {
                let v=UIView.init(frame: CGRectMake(CGFloat(x)*CGFloat(w), CGFloat(y)*CGFloat(h), CGFloat(w), CGFloat(h)));
                v.layer.cornerRadius=12.5;
                v.layer.masksToBounds=true;
                
                let value = array[x*10+y];
                // // 1 live，0 die
                if value == 1 {
                    v.backgroundColor=UIColor.greenColor();
                }else{
                    v.backgroundColor=UIColor.lightGrayColor();
                }
                
                self.contentview .addSubview(v);
            }
        }
    }
}
