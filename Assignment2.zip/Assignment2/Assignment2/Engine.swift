//
//  Engine.swift
//  Assignment2
//
//  Created by 123 on 16/7/4.
//  Copyright © 2016年 AdoT. All rights reserved.
//

import UIKit

class Engine: NSObject {

    static var array:[Int]=[];
    
    static func randomXY() {
        array.removeAll();
        for _ in 0..<10 {
            for _ in 0..<10 {
                let value=arc4random()%UInt32(2);
                array.append(Int(value));
            }
        }
    }
    
    
    static func getComputingXY()->(index_x:Int,index_y:Int){
        
        for x in 0..<10 {
            for y in 0..<10 {
                let value=array[y*10+x];
                if value==1 {
                    if check(y, y: x, value: value) {
                        return (y,x);
                    }
                }
            }
        }
        //no
        return (10,10);
    }
    
    
    static func check(x:Int,y:Int,value:Int)->Bool{
        var indexX=x;
        var indexY=y;
        
        var num=0;
        
        //liev cells
        if value == 1 {
            //up
            if indexY-1>=0 {
                while indexY>=0 {
                    indexY-=1;
                    if indexY>=0&&(array[indexY*10+indexX]==1) {
                        num+=1;
                    }else{
                        break;
                    }
                }
            }
            
            if num>=2&&num<=3 {
                return true;
            }
            
            //down
            
            indexX=x;
            indexY=y;
            num=0;
            if indexY+1>=0 {
                while indexY<10 {
                    indexY+=1;
                    if indexY<10&&(array[indexY*10+indexX]==1) {
                        num+=1;
                    }else{
                        break;
                    }
                }
            }
            
            if num>=2&&num<=3 {
                return true;
            }
            
            //left
            indexX=x;
            indexY=y;
            num=0;
            
            if indexX>=0 {
                while indexX>=0 {
                    indexX-=1;
                    if indexX>=0&&(array[indexY*10+indexX]==1) {
                        num+=1;
                    }else{
                        break;
                    }
                }
            }
            if num>=2&&num<=3 {
                return true;
            }
            
            //right
            indexX=x;
            indexY=y;
            num=0;
            
            if indexX<10 {
                while indexX<10 {
                    indexX+=1;
                    if indexX<10&&(array[indexY*10+indexX]==1) {
                        num+=1;
                    }else{
                        break;
                    }
                }
            }
            if num>=2&&num<=3 {
                return true;
            }
           
        }
         return false;
    }
    
    
     // 1 live，0 die
   static func algorithm()->[Int]{
    randomXY();
    
        for x in 0..<10 {
            for y in 0..<10 {
                let value=array[y*10+x];
                
                
                var index_x=x;
                var index_y=y
                var num=0;
                
                //liev cells
                if value == 1 {
                    //up
                    if (index_y-1>=0){
                        while index_y >= 0 {
                            index_y-=1;
                            if index_y>=0&&(array[index_y*10+index_x]==1) {
                                num+=1;
                            }else{
                                break;
                            }
                        }
                    }
                    
                    
                    if num>=2 && num<=3 {
                         //liev cells
                        continue;
                    }else{
                        //down
                        index_y=y;
                        index_x=x;
                        num=0;
                        
                        if (index_y+1) < 10 {
                            while index_y<10 {
                                index_y+=1;
                                
                                if index_y<10&&(array[index_y*10+index_x]==1){
                                    num+=1;
                                }else{
                                    break;
                                }
                            }
                        }
                        
                        
                        if num>=2 && num<=3 {
                            //liev cells
                            continue;
                        }else{
                            //right
                            index_x=x;
                            index_y=y;
                            num=0;
                            
                            if (index_x-1)>=0 {
                                while index_x>=0 {
                                    index_x-=1;
                                    
                                    if index_x>=0&&(array[index_y*10+index_x]==1) {
                                        num+=1;
                                    }else{
                                        break;
                                    }
                                    
                                }
                            }
                            
                            
                            
                            if num>=2 && num<=3 {
                                //liev cells
                                continue;
                            }else{
                                //right
                                
                                index_x=x;
                                index_y=y;
                                num=0;
                                
                                if (index_x+1)<10 {
                                    while index_x<10 {
                                        index_x+=1;
                                        
                                        if index_x<10&&(array[index_y*10+index_x]==1) {
                                            num+=1;
                                        }else{
                                            break;
                                        }
                                    }
                                }
                                
                                if num>=2&&num<=3 {
                                    continue;
                                }else{
                                    array[x*10+y]=0;
                                }
                            }
                        }
                    }
                }else{
                    //die cells
                    //up
                    index_y=y;
                    index_x=x;
                    num=0;
                    
                    if (index_y-1)>=0 {
                        while index_y>=0 {
                            index_y-=1;
                            
                            
                            if index_y>=0&&(array[index_y*10+index_x]==1) {
                                num+=1;
                            }else{
                                break;
                            }
                        }
                    }
                    
                    
                    
                    if num==3 {
                        array[x*10+y]=1;
                        continue;
                    }else{
                        //down
                        index_x=x;
                        index_y=y;
                        num=0;
                        
                        if (index_y+1)<10 {
                            while index_y<10 {
                                index_y+=1;
                                
                                if index_y<10&&(array[index_y*10+index_x]==1) {
                                    num+=1;
                                }else{
                                    break;
                                }
                            }
                        }
                        
                        
                        
                        if num==3 {
                            array[x*10+y]=1;
                            continue;
                        }else{
                            //left
                            index_y=y;
                            index_x=x;
                            num=0;
                            
                            if (index_x-1)>=0 {
                                while index_x>=0 {
                                    index_x-=1;
                                    
                                    
                                    if index_x>=0&&(array[index_y*10+index_x]==1) {
                                        num+=1;
                                    }else{
                                        break;
                                    }
                                    
                                }
                            }
                            
                            
                            
                            if num==3 {
                                array[x*10+y]=1;
                                continue;
                            }else{
                                //right
                                num=0;
                                index_x=x;
                                index_y=y;
                                
                                if (index_x+1)<10 {
                                    while index_x<10 {
                                        index_x+=1;
                                        
                                        if  index_x<10&&(array[index_y*10+index_x]==1) {
                                            num+=1;
                                        }else{
                                            break;
                                        }
                                    }
                                }
                                
                                
                                if num==3 {
                                    array[x*10+y]=1;
                                    continue;
                                }
                            }
                        }
                    }
                }
            }
        }
    
    return array;
    }
}
