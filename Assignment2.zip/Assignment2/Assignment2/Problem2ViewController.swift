//
//  Problem2ViewController.swift
//  Assignment2
//
//  Created by AdoT on 6/30/16.
//  Copyright © 2016 AdoT. All rights reserved.
//

import UIKit

class Problem2ViewController: UIViewController {

    let width=250;
    let height=250;
    var array:[Int]=[];
    
    @IBOutlet var contentview: UIView!
    
    @IBOutlet var tiplabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.view.backgroundColor=UIColor.whiteColor();
    }
    
    @IBAction func ClickMe(sender: AnyObject) {
        step();
    }
    
    func step(){
        for view in self.contentview.subviews {
            view.removeFromSuperview();
        }
        randomXY();
        algorithm();
        AddUI();
        
        var count=0;
        
        for value in array {
            if value == 1 {
                count+=1;
            }
        }
        let text=NSString.init(format: "live cells:%d", count);
        self.tiplabel.text=text as String;
    }
    
    func AddUI() {
        
        let w=width/10;
        let h=height/10;
        
        for x in 0..<10 {
            for y in 0..<10 {
                let v=UIView.init(frame: CGRectMake(CGFloat(x)*CGFloat(w), CGFloat(y)*CGFloat(h), CGFloat(w), CGFloat(h)));
                v.layer.cornerRadius=12.5;
                v.layer.masksToBounds=true;
                
                let value = array[x*10+y];
                // // 1 live，0 die
                if value == 1 {
                    v.backgroundColor=UIColor.greenColor();
                }else{
                    v.backgroundColor=UIColor.lightGrayColor();
                }
                
                self.contentview .addSubview(v);
            }
        }
    }
    
     func randomXY() {
        array.removeAll();
        for _ in 0..<10 {
            for  _ in 0..<10 {
                let value=arc4random()%UInt32(2);
                array.append(Int(value));
            }
        }
    }
    
    // 1 live，0 die
     func algorithm(){
        
        for i in 0..<10 {
            for j in 0..<10 {
                let value=array[j*10+i];
                
                var index_x=i;
                var index_y=j
                var num=0;
                
                //live cells
                if value == 1 {
                    //up
                    if (index_y-1>=0){
                        while index_y >= 0 {
                            index_y-=1;
                            if index_y>=0&&(array[index_y*10+index_x] == 1) {
                                num+=1;
                            }else{
                                break;
                            }
                        }
                    }
                    
                    
                    if num>=2 && num<=3 {
                        //cells live
                        continue;
                    }else{
                        //down
                      index_x=i;
                      index_y=j
                      num=0;
                        
                        if (index_y+1) < 10 {
                            while index_y<10 {
                                index_y+=1;
                                
                                if index_y<10&&(array[index_y*10+index_x] == 1 ){
                                    num+=1;
                                }else{
                                    break;
                                }
                            }
                        }
                        
                        
                        if num>=2 && num<=3 {
                            //cells live
                            continue;
                        }else{
                            //left
                            index_x=i;
                            index_y=j
                            num=0;
                            
                            if (index_x-1)>=0 {
                                while index_x>=0 {
                                    index_x-=1;
                                    
                                    if index_x>=0&&(array[index_y*10+index_x] == 1) {
                                        num+=1;
                                    }else{
                                        break;
                                    }
                                    
                                }
                            }
                            
                            
                            
                            if num>=2 && num<=3 {
                                //cells live
                                continue;
                            }else{
                                //right
                                
                                index_x=i;
                                index_y=j
                                num=0;
                                
                                if (index_x+1)<10 {
                                    while index_x<10 {
                                        index_x+=1;
                                        
                                        if index_x<10&&(array[index_y*10+index_x] == 1) {
                                            num+=1;
                                        }else{
                                            break;
                                        }
                                    }
                                }
                                
                                if num>=2&&num<=3 {
                                    continue;
                                }else{
                                    array[j*10+i]=0;
                                }
                            }
                        }
                    }
                }else{
                    //die cells
                    //up
                    index_x=i;
                    index_y=j
                    num=0;
                    
                    if (index_y-1)>=0 {
                        while index_y>=0 {
                            index_y-=1;
                            
                            
                            if index_y>=0&&(array[index_y*10+index_x] == 1) {
                                num+=1;
                            }else{
                                break;
                            }
                        }
                    }
                    
                    if num==3 {
                        array[j*10+i]=1;
                        continue;
                    }else{
                        //down
                        index_x=i;
                        index_y=j
                        num=0;
                        
                        if (index_y+1)<10 {
                            while index_y<10 {
                                index_y+=1;
                                
                                if index_y<10&&(array[index_y*10+index_x] == 1) {
                                    num+=1;
                                }else{
                                    break;
                                }
                            }
                        }
                        
                        
                        
                        if num==3 {
                            array[j*10+i]=1;
                            continue;
                        }else{
                            //left
                            index_x=i;
                            index_y=j
                            num=0;
                            
                            if (index_x-1)>=0 {
                                while index_x>=0 {
                                    index_x-=1;
                                    
                                    
                                    if index_x>=0&&(array[index_y*10+index_x] == 1) {
                                        num+=1;
                                    }else{
                                        break;
                                    }
                                    
                                }
                            }
                            
                            
                            
                            if num==3 {
                                array[j*10+i]=1;
                                continue;
                            }else{
                                //right
                                index_x=i;
                                index_y=j
                                num=0;
                                if (index_x+1)<10 {
                                    while index_x<10 {
                                        index_x+=1;
                                        
                                        if  index_x<10&&(array[index_y*10+index_x] == 1) {
                                            num+=1;
                                        }else{
                                            break;
                                        }
                                    }
                                }
                                
                                
                                if num==3 {
                                    array[j*10+i]=1;
                                    continue;
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
