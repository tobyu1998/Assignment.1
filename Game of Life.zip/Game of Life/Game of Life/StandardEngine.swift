//
//  StandardEngine.swift
//  Assignment4
//
//  Created by AdoT on 7/13/16.
//  Copyright © 2016 AdoT. All rights reserved.
//

import UIKit

enum CellState: String{
    case  Living = "Living"
    case  Empty = "Empty"
    case  Born = "Born"
    case  Died = "Died"
}




class StandardEngine : NSObject,EngineProtocol{
    
    var delegate: EngineDelegate?;
    var grid: GridProtocol?;
    var refreshRate: Double = 0.0
    var refreshTimer: NSTimer = NSTimer.init();
    var rows: Int = 10;
    var cols: Int = 10;
    
    var open:Bool=false;
    
    var timef:Float=0.0;
    
    var name:String=""
    
    static let sharedInstance = StandardEngine();
    
 
    static func shareInstance() -> StandardEngine {
        return sharedInstance;
    }
    
    func step() -> GridProtocol{
        
        return grid!;
    }
    
    func Setup(cellstate:[CellState])->[CellState]{
        var array:[CellState]=cellstate;
        for y in 0..<cols {
            for x in 0..<rows {
                let value=array[y*cols+x];
                
                var index_x=x;
                var index_y=y;
                var num=0;
        
                
                //live cells
                if value == CellState.Living || value == CellState.Born{
                    //up
                    if (index_y-1>=0){
                        while index_y >= 0 {
                            index_y-=1;
                            if index_y>=0&&(array[index_y*cols+index_x]==CellState.Living||array[index_y*cols+index_x]==CellState.Born) {
                                num+=1;
                            }else{
                                break;
                            }
                        }
                    }
                    //down
                    index_y=y;
                    index_x=x;
                    num=0;
                    
                    if (index_y+1) < cols {
                        while index_y<cols {
                            index_y+=1;
                            
                            if index_y<cols&&(array[index_y*cols+index_x]==CellState.Living||array[index_y*cols+index_x]==CellState.Born){
                                num+=1;
                            }else{
                                break;
                            }
                        }
                    }
                    
                    
                    if num>=2 && num<=3 {
                        //live cells
                        continue;
                    }else{
                        //left
                        index_x=x;
                        index_y=y;
                        num=0;
                        if (index_x-1)>=0 {
                            while index_x>=0 {
                                index_x-=1;
                                
                                if index_x>=0&&(array[index_y*cols+index_x]==CellState.Living||array[index_y*cols+index_x]==CellState.Born) {
                                    num+=1;
                                }else{
                                    break;
                                }
                            }
                        }
                        //right
                        
                        index_x=x;
                        index_y=y;
                        num=0;
                        
                        if (index_x+1)<rows {
                            while index_x<rows {
                                index_x+=1;
                                
                                if index_x<rows&&(array[index_y*cols+index_x]==CellState.Living||array[index_y*cols+index_x]==CellState.Born) {
                                    num+=1;
                                }else{
                                    break;
                                }
                            }
                        }
                        
                        if num>=2&&num<=3 {
                            continue;
                        }else{
                            array[y*cols+x]=CellState.Died;
                        }
                    }
                }else{
                    //die cells
                    //up
                    index_y=y;
                    index_x=x;
                    num=0;
                    
                    if (index_y-1)>=0 {
                        while index_y>=0 {
                            index_y-=1;
                            
                            if index_y>=0&&(array[index_y*cols+index_x]==CellState.Living) {
                                num+=1;
                            }else{
                                break;
                            }
                        }
                    }
                    
                    //down
                    index_x=x;
                    index_y=y;
                    
                    if (index_y+1)<cols {
                        while index_y<cols {
                            index_y+=1;
                            
                            if index_y<cols&&(array[index_y*cols+index_x]==CellState.Living) {
                                num+=1;
                            }else{
                                break;
                            }
                        }
                    }
                    
                    
                    
                    if num==3 {
                        array[y*cols+x]=CellState.Born;
                        continue;
                    }else{
                        //left
                        index_y=y;
                        index_x=x;
                        num=0;
                        
                        if (index_x-1)>=0 {
                            while index_x>=0 {
                                index_x-=1;
                                
                                
                                if index_x>=0&&(array[index_y*cols+index_x]==CellState.Living) {
                                    num+=1;
                                }else{
                                    break;
                                }
                                
                            }
                        }
                        
                        //right
                        index_x=x;
                        index_y=y;
                        
                        if (index_x+1)<rows {
                            while index_x<rows {
                                index_x+=1;
                                
                                if  index_x<rows&&(array[index_y*cols+index_x]==CellState.Living) {
                                    num+=1;
                                }else{
                                    break;
                                }
                            }
                        }
                        
                        
                        if num==3 {
                            array[y*cols+x]=CellState.Born;
                            continue;
                        }
                    }
                }
               
            }
        }
         return array;
    }
}
