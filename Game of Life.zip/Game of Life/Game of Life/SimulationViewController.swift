//
//  SecondViewController.swift
//  Assignment4
//
//  Created by AdoT on 7/13/16.
//  Copyright © 2016 AdoT. All rights reserved.
//

import UIKit

class SimulationViewController: UIViewController,EngineDelegate{
    
    @IBOutlet var gridview: GridView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        NSNotificationCenter.defaultCenter().addObserver(self, selector:#selector(Change), name: "CELLCHANGE", object: nil);
        
        setup();
    }
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated);
        setup();
        
        if StandardEngine.sharedInstance.open {
                StandardEngine.sharedInstance.refreshTimer=NSTimer.scheduledTimerWithTimeInterval(Double(StandardEngine.sharedInstance.timef), target: self, selector: #selector(Refrash), userInfo: nil, repeats: true);
        }
    }
    
    override func viewWillDisappear(animated: Bool) {
        super.viewWillDisappear(animated);
        StandardEngine.sharedInstance.refreshTimer.invalidate();
    }
    
    @objc func Refrash(timer:NSTimer){
        gridview.cellstate=StandardEngine.sharedInstance.Setup(gridview.cellstate);
        gridview.setNeedsDisplay();
        pushNotify();
    }
    
    
    @objc func Change(){
        pushNotify();
    }
    
    func allValues() -> [CellState] {
        var array:[CellState]=[];
        for _ in 0..<StandardEngine.sharedInstance.rows {
            for _ in 0..<StandardEngine.sharedInstance.cols {
                array.append(CellState.Empty);
            }
        }
        return array;
    }
    
    func toggle(value:CellState) -> CellState {
        if value == CellState.Empty || value == CellState.Died {
            return CellState.Living;
        }
        
        if value == CellState.Living || value == CellState.Born {
            return CellState.Empty;
        }
        return CellState.Died;
    }
    
    func setup() {
        gridview.rows=CGFloat(StandardEngine.sharedInstance.rows);
        gridview.cols=CGFloat(StandardEngine.sharedInstance.cols);
        gridview.cellstate=allValues();
        gridview.cellstate=StandardEngine.sharedInstance.Setup(gridview.cellstate);
        gridview.ctrl=self;
        gridview.setNeedsDisplay();
    }
    
    func engineDidUpdate(withGrid:GridProtocol)
    {
        
    }
    
    
    @IBAction func ClickCycle(sender: AnyObject) {
        gridview.cellstate=StandardEngine.sharedInstance.Setup(gridview.cellstate);
        gridview.setNeedsDisplay();
        pushNotify();
    }
    
    
    @IBAction func ClickSave(sender: AnyObject) {
        let message=String(format: "name is %@",StandardEngine.sharedInstance.name)
        let alertController = UIAlertController(title: "tip", message: message, preferredStyle: UIAlertControllerStyle.Alert)
        let cancelAction = UIAlertAction(title: "Cancel", style: UIAlertActionStyle.Cancel, handler: nil)
        let okAction = UIAlertAction(title: "OK", style: UIAlertActionStyle.Default, handler: nil)
        alertController.addAction(cancelAction)
        alertController.addAction(okAction)
        self.presentViewController(alertController, animated: true,completion: nil);
        
    }
    
    func pushNotify(){
        var count=0;
        for cellstate in gridview.cellstate {
            if cellstate == CellState.Living {
                count+=1;
            }
        }
        let  obj=NSNumber(integer: count)
        
        
        var borncount=0;
        for cellstate in gridview.cellstate {
            if cellstate == CellState.Born {
                borncount+=1;
            }
        }
        let  bornobj=NSNumber(integer: borncount)
        
        var diedcount=0;
        for cellstate in gridview.cellstate {
            if cellstate == CellState.Died {
                diedcount+=1;
            }
        }
        let  diedobj=NSNumber(integer: diedcount)
        
        var emotycount=0;
        for cellstate in gridview.cellstate {
            if cellstate == CellState.Empty {
                emotycount+=1;
            }
        }
        let  emptyobj=NSNumber(integer: emotycount)
        
        let object=["live":obj,"born":bornobj,"died":diedobj,"empty":emptyobj];
        
        NSNotificationCenter.defaultCenter().postNotificationName("CHANGECOUNT", object: object);
    }
}

