//
//  GridView.swift
//  Assignment3
//
//  Created by AdoT on 7/7/16.
//  Copyright © 2016 AdoT. All rights reserved.
//

import UIKit

@IBDesignable
class GridView: UIView {
    
    @IBInspectable var rows: CGFloat = 20.0;
    @IBInspectable var cols: CGFloat = 20.0;
    @IBInspectable var gridwidth:CFloat=2.0;
    var cellstate:[CellState] = [];
    
    @IBInspectable var livingColor: UIColor = UIColor.greenColor();
    @IBInspectable var emptyColor: UIColor = UIColor.lightGrayColor();
    @IBInspectable var bornColor: UIColor = UIColor.yellowColor()
    @IBInspectable var diedColor: UIColor = UIColor(red: 54/255, green: 19/255, blue: 0/255, alpha: 1.0);
    @IBInspectable var gridColor: UIColor = UIColor.blackColor();

    
    var ctrl:SimulationViewController? = nil;
    var points:[(Int,Int)] = [];
  
    
    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
        let touch:UITouch!=touches.first;
        let point=touch.locationInView(self) ;
        
         let w=CGFloat(Float(self.bounds.size.width)/Float(StandardEngine.sharedInstance.rows));
        let pointx=point.x/w;
        let pointy=point.y/w;
        let x=Int(pointx);
        let y=Int(pointy);
        
        cellstate[y*Int(rows)+x]=CellState.Living;
        
        setNeedsDisplay();
    }
    
    func setPoints(params:[(Int,Int)]){
        points=params;
        
    }
    
    
    func getPoints(x:Int,y:Int) -> CellState {
        return cellstate[x*20+y];
    }
    
    
    override func drawRect(rect: CGRect) {
        
        let ctx=UIGraphicsGetCurrentContext();
        
        let width=CGFloat(Float(self.bounds.size.width)/Float(StandardEngine.sharedInstance.rows));
        
        
        
        for i in 0...StandardEngine.sharedInstance.rows {
            //hor line
            CGContextSetRGBStrokeColor(ctx, 0.820, 0.820, 0.820, 1.0);
            CGContextMoveToPoint(ctx, 0, CGFloat(i)*width);
            CGContextSetLineWidth(ctx, CGFloat(gridwidth));
            CGContextAddLineToPoint(ctx,self.bounds.size.width,CGFloat(i)*width);
            CGContextStrokePath(ctx);
        }
        
        for i in 0...StandardEngine.sharedInstance.cols {
            //ver line
            CGContextSetRGBStrokeColor(ctx, 0.820, 0.820, 0.820, 1.0);
            CGContextMoveToPoint(ctx, CGFloat(i)*width, 0);
            CGContextSetLineWidth(ctx, CGFloat(gridwidth));
            CGContextAddLineToPoint(ctx,CGFloat(i)*width,self.bounds.size.height);
            CGContextStrokePath(ctx);
        }
        
        
        //circle
        for y in 0..<StandardEngine.sharedInstance.rows {
            for x in 0..<StandardEngine.sharedInstance.cols {
                let state=cellstate[y*StandardEngine.sharedInstance.rows+x];
                if state == CellState.Living {
                    CGContextSetFillColorWithColor(ctx,livingColor.CGColor);
                }else if state == CellState.Empty {
                    CGContextSetFillColorWithColor(ctx,emptyColor.CGColor);
                }else if state == CellState.Born {
                    CGContextSetFillColorWithColor(ctx,bornColor.CGColor);
                }else if state == CellState.Died {
                    CGContextSetFillColorWithColor(ctx,diedColor.CGColor);
                }
                CGContextAddArc(ctx, CGFloat(x)*width+width/2.0, CGFloat(y)*width+width/2.0, width/2.0, 0, CGFloat(2*M_PI), 0);
                CGContextFillPath(ctx);
            }
        }
    }
}


