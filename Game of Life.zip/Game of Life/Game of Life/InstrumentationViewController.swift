//
//  FirstViewController.swift
//  Game of Life
//
//  Created by AdoT on 2016/7/27.
//  Copyright © 2016年 AdoT. All rights reserved.
//

import UIKit

class InstrumentationViewController : UIViewController,UITableViewDataSource,UITableViewDelegate {

    
    
    @IBOutlet var rows: UITextField!
    
    @IBOutlet var colou: UITextField!
    
    @IBOutlet var rowssteop: UIStepper!
    @IBOutlet var slidertf: UITextField!
    
    @IBOutlet var rowmarginleft: NSLayoutConstraint!
    @IBOutlet var colsstup: UIStepper!

    @IBOutlet var tableview: UITableView!
    
    @IBOutlet var website: UITextField!
    var data:NSMutableArray!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.rows.text=NSString.init(format: "%.0f", rowssteop.value) as String;
        
        self.colou.text=NSString.init(format: "%.0f", colsstup.value) as String;
        StandardEngine.sharedInstance.rows=Int(rowssteop.value);
        StandardEngine.sharedInstance.rows=Int(colsstup.value);
     
        self.slidertf.text=NSString.init(format: "%.1f", 0.5) as String;
        
        self.rowmarginleft.constant=(self.view.bounds.size.width-190)/2.0;
        
        data=NSMutableArray();
        
        refreshData("https://dl.dropboxusercontent.com/u/7544475/S65g.json")
    }
    
    func refreshData(text:String) {
        let url=NSURL(string: text)!;
        let fetcher = Fetcher()
        fetcher.requestJSON(url) { (json, message) in
            let op = NSBlockOperation {
                if let json = json {
                    self.data.addObjectsFromArray(json as! [AnyObject]);
                    _ = NSBlockOperation {
                        self.tableview.reloadData();
                    }
                }
            }
            NSOperationQueue.mainQueue().addOperation(op)
        }
    }
    
    @IBAction func ValueChangeSlider(sender: UISlider) {
        StandardEngine.sharedInstance.timef=sender.value;
    }
    
    @IBAction func ClickStart(sender: AnyObject) {
        StandardEngine.sharedInstance.open=true;
    }
    
    
    @IBAction func ClickStop(sender: AnyObject) {
        StandardEngine.sharedInstance.open=false;
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
    @IBAction func ClickRefresh(sender: AnyObject) {
        let text=website.text;
        refreshData(text!);
    }
    
    
    @IBAction func Clickrows(sender: UIStepper) {
        
        self.rows.text=NSString.init(format: "%.0f", sender.value) as String;
        
        colsstup.value=sender.value;
        self.colou.text=NSString.init(format: "%.0f", colsstup.value) as String;
        StandardEngine.sharedInstance.rows=Int(sender.value)
        StandardEngine.sharedInstance.cols=Int(colsstup.value)
    }
    
    
    @IBAction func Clickrolou(sender: UIStepper) {
        self.colou.text=NSString.init(format: "%.0f", sender.value) as String
        
        rowssteop.value=sender.value
        StandardEngine.sharedInstance.cols=Int(sender.value)
        self.rows.text=NSString.init(format: "%.0f", rowssteop.value) as String
        StandardEngine.sharedInstance.rows=Int(rowssteop.value)
    }
    
    @IBAction func ClickSlidervalue(sender: UISlider) {
        
        self.slidertf.text=NSString.init(format: "%.1f", sender.value) as String
    }
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return self.data.count
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        let dic=self.data.objectAtIndex(section)
        return (dic.objectForKey("contents")?.count)!
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell
    {
        guard let cell = tableView.dequeueReusableCellWithIdentifier("Default")
            else {
                preconditionFailure("missing Default reuse identifier")
        }
        let row = indexPath.row
        guard let nameLabel = cell.textLabel else {
            preconditionFailure("wtf?")
        }
        
        let str=self.data.objectAtIndex(indexPath.section).objectForKey("contents")?.objectAtIndex(indexPath.row).description
        
        nameLabel.text = str
        cell.tag = row
        return cell
    }
 
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        let dic=self.data.objectAtIndex(indexPath.section) as! NSDictionary;
        StandardEngine.sharedInstance.name=(dic.objectForKey("title") as? String)!;
        
        let array=dic.objectForKey("contents")?.objectAtIndex(indexPath.row);
        
        
        StandardEngine.sharedInstance.rows=array![0] as! Int;
        StandardEngine.sharedInstance.cols=array![1] as! Int;
    }
    
}

