//
//  GridView.swift
//  Assignment3
//
//  Created by AdoT on 7/7/16.
//  Copyright © 2016 AdoT. All rights reserved.
//

import UIKit

@IBDesignable
class GridView: UIView {
    
    @IBInspectable var rows: CGFloat = 20.0;
    @IBInspectable var cols: CGFloat = 20.0;
    @IBInspectable var gridwidth:CFloat=2.0;
    var cellstate:[CellState] = [];
//    var didset:[String] = [];
    
    @IBInspectable var livingColor: UIColor = UIColor.greenColor();
    @IBInspectable var emptyColor: UIColor = UIColor.darkGrayColor();
    @IBInspectable var bornColor: UIColor = UIColor(red: 0, green: 255, blue: 1, alpha: 0.6);
    @IBInspectable var diedColor: UIColor = UIColor(red: 96/255, green: 96/255, blue: 96/255, alpha: 0.6);
    @IBInspectable var gridColor: UIColor = UIColor.blackColor();
    
    var ctrl:ViewController? = nil;
  
    
    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
        let touch:UITouch!=touches.first;
        let point=touch.locationInView(self) ;
        let pointx=point.x/15;
        let pointy=point.y/15;
        let x=Int(pointx);
        let y=Int(pointy);
        
        let state=cellstate[y*20+x];
        cellstate[y*20+x]=(ctrl?.toggle(state))!;
//        didset[y*20+x]="disSet";
        
        setNeedsDisplay();
    }
    
    
    override func drawRect(rect: CGRect) {
        
        let ctx=UIGraphicsGetCurrentContext();
        
        for i in 0...20 {
            //hor line
            CGContextSetRGBStrokeColor(ctx, 0.820, 0.820, 0.820, 1.0);
            CGContextMoveToPoint(ctx, 0, CGFloat(i)*15);
            CGContextSetLineWidth(ctx, CGFloat(gridwidth));
            CGContextAddLineToPoint(ctx,self.bounds.size.width,CGFloat(i)*15);
            CGContextStrokePath(ctx);
        }
        
        for i in 0...20 {
            //ver line
             CGContextSetRGBStrokeColor(ctx, 0.820, 0.820, 0.820, 1.0);
            CGContextMoveToPoint(ctx, CGFloat(i)*15, 0);
            CGContextSetLineWidth(ctx, CGFloat(gridwidth));
            CGContextAddLineToPoint(ctx,CGFloat(i)*15,self.bounds.size.height);
            CGContextStrokePath(ctx);
        }
        
        
        //circle
        for y in 0..<20 {
            for x in 0..<20 {
                let state=cellstate[y*20+x];
                if state == CellState.Living {
                    CGContextSetFillColorWithColor(ctx,livingColor.CGColor);
                }else if state == CellState.Empty {
                    CGContextSetFillColorWithColor(ctx,emptyColor.CGColor);
                }else if state == CellState.Born {
                    CGContextSetFillColorWithColor(ctx,bornColor.CGColor);
                }else if state == CellState.Died {
                    CGContextSetFillColorWithColor(ctx,diedColor.CGColor);
                }
               CGContextAddArc(ctx,CGFloat(x)*15+7.5,CGFloat((y)*15)+7.5, 7.5, 0, CGFloat(2*M_PI), 0);
               CGContextFillPath(ctx);
            }
        }
    }
}


