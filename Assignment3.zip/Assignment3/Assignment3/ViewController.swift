//
//  ViewController.swift
//  Assignment3
//
//  Created by AdoT on 7/7/16.
//  Copyright © 2016 AdoT. All rights reserved.
//

import UIKit

enum CellState: String{
    case  Living = "Living"
    case  Empty = "Empty"
    case  Born = "Born"
    case  Died = "Died"
}

class ViewController: UIViewController {
    @IBOutlet var gridview: GridView!
    override func viewDidLoad() {
        super.viewDidLoad()
        setup();
    }
    
    
    @IBAction func ClickSetup(sender: AnyObject) {
        gridview.cellstate=Setup();
        gridview.setNeedsDisplay();
    }
    
    func Setup()->[CellState]{
        var array:[CellState]=gridview.cellstate;
        for y in 0..<20 {
            for x in 0..<20 {
                let value=array[y*20+x];
                
                var index_x=x;
                var index_y=y
                var num=0;
                
                //liev cells
                if value == CellState.Living {
                    //up
                    if (index_y-1>=0){
                        while index_y >= 0 {
                            index_y-=1;
                            if index_y>=0&&(array[index_y*20+index_x]==CellState.Living) {
                                num+=1;
                            }else{
                                break;
                            }
                        }
                    }
                    
                    
                    if num>=2 && num<=3 {
                        //liev cells
                        continue;
                    }else{
                        //down
                        index_y=y;
                        index_x=x;
                        num=0;
                        
                        if (index_y+1) < 20 {
                            while index_y<20 {
                                index_y+=1;
                                
                                if index_y<20&&(array[index_y*20+index_x]==CellState.Living){
                                    num+=1;
                                }else{
                                    break;
                                }
                            }
                        }
                        
                        
                        if num>=2 && num<=3 {
                            //liev cells
                            continue;
                        }else{
                            //right
                            index_x=x;
                            index_y=y;
                            num=0;
                            
                            if (index_x-1)>=0 {
                                while index_x>=0 {
                                    index_x-=1;
                                    
                                    if index_x>=0&&(array[index_y*20+index_x]==CellState.Living) {
                                        num+=1;
                                    }else{
                                        break;
                                    }
                                    
                                }
                            }
                            
                            
                            
                            if num>=2 && num<=3 {
                                //liev cells
                                continue;
                            }else{
                                //right
                                
                                index_x=x;
                                index_y=y;
                                num=0;
                                
                                if (index_x+1)<20 {
                                    while index_x<20 {
                                        index_x+=1;
                                        
                                        if index_x<20&&(array[index_y*20+index_x]==CellState.Living) {
                                            num+=1;
                                        }else{
                                            break;
                                        }
                                    }
                                }
                                
                                if num>=2&&num<=3 {
                                    continue;
                                }else{
                                    array[x*20+y]=CellState.Died;
                                }
                            }
                        }
                    }
                }else{
                    //die cells
                    //up
                    index_y=y;
                    index_x=x;
                    num=0;
                    
                    if (index_y-1)>=0 {
                        while index_y>=0 {
                            index_y-=1;
                            
                            
                            if index_y>=0&&(array[index_y*20+index_x]==CellState.Living) {
                                num+=1;
                            }else{
                                break;
                            }
                        }
                    }
                    
                    
                    
                    if num==3 {
                        array[x*20+y]=CellState.Living;
                        continue;
                    }else{
                        //down
                        index_x=x;
                        index_y=y;
                        num=0;
                        
                        if (index_y+1)<20 {
                            while index_y<20 {
                                index_y+=1;
                                
                                if index_y<20&&(array[index_y*20+index_x]==CellState.Living) {
                                    num+=1;
                                }else{
                                    break;
                                }
                            }
                        }
                        
                        
                        
                        if num==3 {
                            array[x*20+y]=CellState.Living;
                            continue;
                        }else{
                            //left
                            index_y=y;
                            index_x=x;
                            num=0;
                            
                            if (index_x-1)>=0 {
                                while index_x>=0 {
                                    index_x-=1;
                                    
                                    
                                    if index_x>=0&&(array[index_y*20+index_x]==CellState.Living) {
                                        num+=1;
                                    }else{
                                        break;
                                    }
                                    
                                }
                            }
                            
                            
                            
                            if num==3 {
                                array[x*20+y]=CellState.Living;
                                continue;
                            }else{
                                //right
                                num=0;
                                index_x=x;
                                index_y=y;
                                
                                if (index_x+1)<20 {
                                    while index_x<20 {
                                        index_x+=1;
                                        
                                        if  index_x<20&&(array[index_y*20+index_x]==CellState.Living) {
                                            num+=1;
                                        }else{
                                            break;
                                        }
                                    }
                                }
                                
                                
                                if num==3 {
                                    array[x*20+y]=CellState.Living;
                                    continue;
                                }
                            }
                        }
                    }
                }
            }
        }
        return array;
    }
    
    func setup() {
        gridview.cellstate=allValues();
        gridview.ctrl=self;
        gridview.setNeedsDisplay();
    }
    
    func sdescription(){
        
    }
    
    func allValues() -> [CellState] {
        var array:[CellState]=[];
        for _ in 0..<20 {
            for _ in 0..<20 {
                array.append(CellState.Died);
            }
        }
        return array;
    }
    
    func toggle(value:CellState) -> CellState {
        if value == CellState.Empty || value == CellState.Died {
            return CellState.Living;
        }
        
        if value == CellState.Living || value == CellState.Born {
            return CellState.Empty;
        }
        return CellState.Died;
    }
}



