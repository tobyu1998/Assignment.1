//
//  EngineDelegate.swift
//  Assignment4
//
//  Created by AdoT on 7/13/16.
//  Copyright © 2016 AdoT. All rights reserved.
//

import Foundation

protocol EngineDelegate {
    func engineDidUpdate(withGrid:GridProtocol);
}