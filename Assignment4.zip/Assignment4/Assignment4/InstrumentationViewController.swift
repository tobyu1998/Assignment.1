//
//  FirstViewController.swift
//  Assignment4
//
//  Created by AdoT on 7/13/16.
//  Copyright © 2016 AdoT. All rights reserved.
//

import UIKit

class InstrumentationViewController: UIViewController {

    @IBOutlet var rows: UITextField!
    
    @IBOutlet var colou: UITextField!
    @IBOutlet var switch_ui: UISwitch!
    
    @IBOutlet var rowssteop: UIStepper!
    @IBOutlet var slidertf: UITextField!
    
    @IBOutlet var rowmarginleft: NSLayoutConstraint!
    
    @IBAction func ClickSwitfh(sender: UISwitch) {
        StandardEngine.sharedInstance.open=sender.on
    }
    
    @IBOutlet var colsstup: UIStepper!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.rows.text=NSString.init(format: "%.0f", rowssteop.value) as String;
        
        self.colou.text=NSString.init(format: "%.0f", colsstup.value) as String;
        StandardEngine.sharedInstance.rows=Int(rowssteop.value);
        StandardEngine.sharedInstance.rows=Int(colsstup.value);
        StandardEngine.sharedInstance.open=switch_ui.on;
        self.slidertf.text=NSString.init(format: "%.1f", 0.5) as String;
        
        self.rowmarginleft.constant=(self.view.bounds.size.width-190)/2.0;
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }

    @IBAction func Clickrows(sender: UIStepper) {
        
        self.rows.text=NSString.init(format: "%.0f", sender.value) as String;
        
        colsstup.value=sender.value;
        self.colou.text=NSString.init(format: "%.0f", colsstup.value) as String;
        StandardEngine.sharedInstance.rows=Int(sender.value);
        StandardEngine.sharedInstance.cols=Int(colsstup.value);
    }

   
    @IBAction func Clickrolou(sender: UIStepper) {
        self.colou.text=NSString.init(format: "%.0f", sender.value) as String;
        
        rowssteop.value=sender.value;
         StandardEngine.sharedInstance.cols=Int(sender.value);
        self.rows.text=NSString.init(format: "%.0f", rowssteop.value) as String;
         StandardEngine.sharedInstance.rows=Int(rowssteop.value);
    }
    @IBAction func ClickSlidervalue(sender: UISlider) {
        
         self.slidertf.text=NSString.init(format: "%.1f", sender.value) as String;
    }
}

