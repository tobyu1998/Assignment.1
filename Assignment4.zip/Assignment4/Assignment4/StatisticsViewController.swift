//
//  StatisticsViewController.swift
//  Assignment4
//
//  Created by AdoT on 7/13/16.
//  Copyright © 2016 AdoT. All rights reserved.
//

import UIKit

class StatisticsViewController: UIViewController {

    
    
    @IBOutlet var label: UILabel!
    
    
    @IBOutlet var born: UILabel!
    
    
    @IBOutlet var died: UILabel!
    
    @IBOutlet var empty: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()

        NSNotificationCenter.defaultCenter().addObserver(self, selector:#selector(ChangeCount(_:)), name: "CHANGECOUNT", object: nil);
        
        label.text=NSString(format: "live cell:%d", 0) as String!;
        born.text=NSString(format: "born cell:%d", 0) as String!;
        died.text=NSString(format: "died cell:%d", 0) as String!;
        empty.text=NSString(format: "empty cell:%d", 0) as String!;
    }
    
    @objc func ChangeCount(notify:NSNotification){
        
        // let object=["live":obj,"born":bornobj,"died":diedobj,"empty":emptyobj];
        let obj=notify.object;
        let liven:NSNumber=obj?.objectForKey("live") as! NSNumber;
        let bornn:NSNumber=obj?.objectForKey("born") as! NSNumber;
        let diedn:NSNumber=obj?.objectForKey("died") as! NSNumber;
        let emptyn:NSNumber=obj?.objectForKey("empty") as! NSNumber;
        
        label.text=NSString(format: "live cell:%d", (liven.integerValue)) as String!;
         born.text=NSString(format: "born cell:%d", (bornn.integerValue)) as String!;
         died.text=NSString(format: "died cell:%d", (diedn.integerValue)) as String!;
         empty.text=NSString(format: "empty cell:%d", (emptyn.integerValue)) as String!;
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
