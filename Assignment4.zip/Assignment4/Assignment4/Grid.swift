//
//  Grid.swift
//  Assignment4
//
//  Created by AdoT on 7/13/16.
//  Copyright © 2016 AdoT. All rights reserved.
//

import UIKit

class Grid : GridProtocol{
 
    var rows: Int = 10;
    var cols: Int = 10;
    
    
    func neighbors() -> (Int,Int){

        return (rows,cols);
    }
}
