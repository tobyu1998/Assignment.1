//: Playground - noun: a place where people can play

import UIKit

func isLeap(year:Int)->Bool
{
    return getLeapYear(year)
}

func getLeapYear(year:Int) -> Bool {
    guard ((year % 100 == 0)&&(year % 400 == 0)||(year % 100 != 0)&&(year % 4 == 0)) else {return false}
    return true
}

func julianDate(year:Int,month:Int,day:Int) -> Int {
    return getTime(getDate(year, month: month, day: day))
}

func getTime(startDate:NSDate) -> Int {
    let startresult = getFormatter().dateFromString("1900-01-01")
    let time=(startDate.timeIntervalSinceDate(startresult!)) as Double
    return Int(time/3600.0/24.0)+1
}

func getDate(year:Int,month:Int,day:Int) -> NSDate {
    return getFormatter().dateFromString(String(year)+"-"+String(month)+"-"+String(day))!
}

func getFormatter() -> NSDateFormatter {
    let dateformatter = NSDateFormatter()
    dateformatter.dateFormat = "yyyy-MM-dd"
    return dateformatter
}

julianDate(1960, month: 9, day: 28)
julianDate(1900, month: 1, day: 1)
julianDate(1900, month: 12, day: 31)
julianDate(1901, month: 1, day: 1)
julianDate(1901, month: 1, day: 1)
julianDate(1900, month: 1, day: 1)
julianDate(2001, month: 1, day: 1)
julianDate(2000, month: 1, day: 1)

isLeap(1960)
isLeap(1900)
isLeap(2000)


